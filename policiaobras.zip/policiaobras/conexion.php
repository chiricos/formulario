<?php
$hots = "localhost";
$user = "root";
$pw = "root";
$db = "formulario";
?>